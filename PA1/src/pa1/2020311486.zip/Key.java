package pa1;

public class Key extends GameObject{

	public Key(int x,int y) {
		/* add your code, you can add parameter, too */
		this.setX(x);
		this.setY(y);
	}
}
